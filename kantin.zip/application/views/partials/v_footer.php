
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\jquery\js\jquery.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\jquery-ui\js\jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\popper.js\js\popper.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\bootstrap\js\bootstrap.min.js"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\jquery-slimscroll\js\jquery.slimscroll.js"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\modernizr\js\modernizr.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\modernizr\js\css-scrollbars.js"></script>
    <!-- data-table js -->
    <script src="<?= base_url(); ?>bower_components\datatables.net\js\jquery.dataTables.min.js"></script>
    <script src="<?= base_url(); ?>bower_components\datatables.net-buttons\js\dataTables.buttons.min.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\js\jszip.min.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\js\pdfmake.min.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\js\vfs_fonts.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\extensions\buttons\js\dataTables.buttons.min.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\extensions\buttons\js\buttons.flash.min.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\extensions\buttons\js\jszip.min.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\extensions\buttons\js\vfs_fonts.js"></script>
    <script src="<?= base_url(); ?>assets\pages\data-table\extensions\buttons\js\buttons.colVis.min.js"></script>
    <script src="<?= base_url(); ?>bower_components\datatables.net-buttons\js\buttons.print.min.js"></script>
    <script src="<?= base_url(); ?>bower_components\datatables.net-buttons\js\buttons.html5.min.js"></script>
    <script src="<?= base_url(); ?>bower_components\datatables.net-bs4\js\dataTables.bootstrap4.min.js"></script>
    <script src="<?= base_url(); ?>bower_components\datatables.net-responsive\js\dataTables.responsive.min.js"></script>
    <script src="<?= base_url(); ?>bower_components\datatables.net-responsive-bs4\js\responsive.bootstrap4.min.js"></script>
    <!-- i18next.min.js -->
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\i18next\js\i18next.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\i18next-xhr-backend\js\i18nextXHRBackend.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\i18next-browser-languagedetector\js\i18nextBrowserLanguageDetector.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\jquery-i18next\js\jquery-i18next.min.js"></script>
    <!-- Custom js -->
    <script src="<?= base_url(); ?>assets\pages\data-table\extensions\buttons\js\extension-btns-custom.js"></script>
    <!-- Custom js -->
    <script type="text/javascript" src="<?= base_url(); ?>assets\pages\j-pro\js\custom\reg-form.js"></script>
    <!-- Bootstrap date-time-picker js -->
    <script type="text/javascript" src="<?= base_url(); ?>assets\pages\advance-elements\moment-with-locales.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\bootstrap-datepicker\js\bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets\pages\advance-elements\bootstrap-datetimepicker.min.js"></script>
    <!-- Date-range picker js -->
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\bootstrap-daterangepicker\js\daterangepicker.js"></script>
    <!-- Date-dropper js -->
    <script type="text/javascript" src="<?= base_url(); ?>bower_components\datedropper\js\datedropper.min.js"></script>

    <!-- Masking js -->
    <script src="<?= base_url(); ?>assets\pages\form-masking\inputmask.js"></script>
    <script src="<?= base_url(); ?>assets\pages\form-masking\jquery.inputmask.js"></script>
    <script src="<?= base_url(); ?>assets\pages\form-masking\autoNumeric.js"></script>
    <script src="<?= base_url(); ?>assets\pages\form-masking\form-mask.js"></script>

    <script src="<?= base_url(); ?>assets\js\pcoded.min.js"></script>
    <script src="<?= base_url(); ?>assets\js\vartical-layout.min.js"></script>
    <script src="<?= base_url(); ?>assets\js\jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets\js\script.js"></script>
    
    
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

</body>

</html>
